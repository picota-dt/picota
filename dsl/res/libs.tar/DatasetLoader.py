from FloatCaster import register_cast

class DatasetLoader:
    def __init__(self, path, line_sep, variables):
        self.path = path
        self.line_sep = line_sep
        self.variables = variables

    def load(self):
        with open(self.path) as dataset:
            data = list(
                map(lambda row: list(map(lambda register: register_cast(register), row.split(self.line_sep))),
                    dataset.readlines()))
            head = data[0]
            unprocessed_dataframe = {column: [] for column in head}
            for index in range(len(head)):
                for row in data[1:]:
                    unprocessed_dataframe[head[index]].append(row[index])
        dataframe = {}
        for v in self.variables: dataframe[v] = unprocessed_dataframe[v]
        return dataframe