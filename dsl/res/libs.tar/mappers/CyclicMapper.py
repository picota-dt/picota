import math

class CyclicMapper:
	def __init__(self, variables, max):
		self.variables = variables
		self.max = max

	def map(self, dataframe: {}):
		for v in self.variables:
			dataframe[v + "_cos"] = self.cos_variable(dataframe[v])
			dataframe[v + "_sin"] = self.sin_variable(dataframe[v])
			del dataframe[v]
		return dataframe


	def cos_variable(self, column: list[float]):
		return list(map(lambda i: math.cos(2 * math.pi * i / self.max),column))

	def sin_variable(self, column: list[float]):
		return list(map(lambda i: math.sin(2 * math.pi * i / self.max), column))
