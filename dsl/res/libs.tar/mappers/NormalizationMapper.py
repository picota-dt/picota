class NormalizationMapper:
	def __init__(self, variables, min=0, max=1):
		self.min = min
		self.max = max
		self.variables = variables

	def map(self, dataframe: {}):
		for v in self.variables: dataframe[v] = self.map_variable(dataframe[v])
		return dataframe


	def map_variable(self, column: list[float]):
		max_in_col = max(column)
		min_in_col = min(column)
		return list(map(lambda register: ((register - min_in_col) / (max_in_col - min_in_col)) * (
					self.max - self.min) + self.min, column))
